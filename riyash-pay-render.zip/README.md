# RIYASH PAY

A small React + Firebase app for creating personal UPI payment reminders. Payers can submit a UPI UTR/reference; the account owner independently checks their own bank/UPI app and manually approves the request.

## Important limitation

This is **manual verification**, not automatic bank verification. A payer-submitted UTR, screenshot, or success screen is only a claim. Never approve unless you can see the matching credit in your own bank/UPI transaction history. The app does not connect to your bank and cannot confirm incoming money automatically.

## 1. Requirements

- Node.js 20 or newer
- A Firebase project
- A Firebase Web App config
- Firebase Authentication (Email/Password)
- Cloud Firestore
- Firebase CLI: `npm install -g firebase-tools`

## 2. Configure Firebase

1. Open https://console.firebase.google.com/ and create a project.
2. Add a Web App in Project Overview and copy its Firebase config.
3. In Authentication > Sign-in method, enable **Email/Password**.
4. In Firestore Database, create a database (production mode is fine).
5. Replace the placeholder values in `src/firebase.js` with your Web App config.
6. In Firestore > Rules, publish the contents of `firestore.rules`.

The first admin account can be created from the app's sign-up screen. Create it yourself and do not share the credentials. After creating the account, disable public account creation:
- Firebase Console > Authentication > Settings > User actions > disable account creation if that option is available for your project, OR
- Delete any unwanted users from Authentication.
The starter app shows sign-up for convenience. Firestore rules allow only authenticated users to create requests and approve payments, but for a production deployment you should restrict admin account creation and consider adding App Check.

## 3. Run locally

```bash
npm install
npm run dev
```

Open the local URL shown by Vite. Sign up with your own email/password.

## 4. Deploy to Firebase Hosting

```bash
npm install -g firebase-tools
firebase login
firebase use --add
```

Choose your Firebase project and set the alias to `default`. Then:

```bash
firebase deploy
```

This deploys Hosting and Firestore rules. Your site URL will look like `https://YOUR_PROJECT_ID.web.app`.

## 5. How to use

1. Sign in to the admin dashboard.
2. Create a request (default amount ₹349).
3. Copy the share link from the request row and send it to your friend.
4. Your friend opens the link, taps Pay, and pays through their UPI app.
5. They return to the page and submit the UPI transaction reference/UTR.
6. You check your own bank/UPI app for the matching ₹349 credit.
7. Only then press **Verify & approve**. The public page changes to Paid.

## Security notes

- Never put Firebase service-account credentials or bank credentials in the frontend.
- Never ask for or collect a UPI PIN, OTP, card PIN, or password.
- Firestore document IDs are difficult to guess but public request documents are readable by anyone who has the link. Do not store sensitive personal data in these documents.
- The demo rules allow a public user to submit a UTR claim, but only a signed-in user can approve it. A signed-in user is treated as the admin; secure account creation before sharing the site.
- For stronger production security, use Firebase App Check and move admin operations into trusted Cloud Functions. Do not rely on client-side validation alone.
- UPI intent availability depends on the payer's device and installed UPI apps. The `upi://` link may not work on every desktop/browser.


## Deploy on Render (Static Site)

This is a Vite + React frontend, so deploy it as a **Static Site**, not a Web Service.

### Option A — Render Blueprint (easiest)

1. Push this project folder to a GitHub repository.
2. Open https://dashboard.render.com/ and connect GitHub if needed.
3. Choose **New > Blueprint** and select the repository containing `render.yaml`.
4. Render reads `render.yaml`; review and create the static site.
5. Wait for the build to finish. Your site will have a URL like `https://riyash-pay.onrender.com`.

### Option B — Create Static Site manually

In Render Dashboard choose **New > Static Site**, connect the GitHub repository, then set:

- Branch: `main` (or your chosen branch)
- Root Directory: leave blank if `package.json` is at repository root
- Build Command: `npm install && npm run build`
- Publish Directory: `dist`

Add a rewrite rule under Redirects/Rewrites:

- Source: `/*`
- Destination: `/index.html`
- Action: Rewrite

Then deploy.

### IMPORTANT: Set Firestore admin UID before public use

1. In Firebase Console > Authentication > Users, copy the UID of the admin account you created.
2. Open `firestore.rules` and replace `REPLACE_WITH_YOUR_ADMIN_UID` with that exact UID.
3. Publish the rules in Firebase Console > Firestore Database > Rules.
4. Do not leave the placeholder in place; otherwise admin actions will be blocked.
5. Create the admin account yourself. Do not share its password. If possible, disable public account creation after creating your admin login.

### Firebase config

Render only hosts the frontend. Firebase still handles sign-in and data. Keep your Firebase Web App config in `src/firebase.js`; its web API key is intended to be public, but configure Firebase API key restrictions and never put service-account/private keys in frontend code.

### Test after deployment

- Open the Render URL and sign in as the admin.
- Create a ₹349 request and copy its link.
- Open that link in a private/incognito tab or another phone.
- Confirm the payer can submit a test UTR.
- Sign in as admin, verify the matching credit in your own UPI/bank app, then approve.
- Confirm the public link changes to Paid.

Do not test with a fabricated UTR and do not approve unless the matching funds are actually credited.
